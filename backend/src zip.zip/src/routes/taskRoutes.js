import express from "express";

import { createTask,
    getTasks,
    getTaskById,
    updateTask,
    archiveTask,
 } from "../controllers/taskController.js";

import { protect } from "../middleware/authMiddleware.js";

import { loadWorkspace } from "../middleware/workspaceMiddleware.js";

import {
    loadWorkspaceMembership,
    isMemberOrOwner,
    isOwner,
} from "../middleware/workspacePermissionMiddleware.js";

import { loadProject } from "../middleware/projectMiddleware.js";

const router = express.Router();

router.post(
    "/:workspaceId/projects/:projectId/tasks",
    protect,
    loadWorkspace,
    loadWorkspaceMembership,
    isMemberOrOwner,
    loadProject,
    createTask
);

router.get(
    "/:workspaceId/projects/:projectId/tasks",
    protect,
    loadWorkspace,
    loadWorkspaceMembership,
    loadProject,
    getTasks
);

router.get(
    "/:workspaceId/projects/:projectId/tasks/:taskId",
    protect,
    loadWorkspace,
    loadWorkspaceMembership,
    loadProject,
    getTaskById
);

router.patch(
    "/:workspaceId/projects/:projectId/tasks/:taskId",
    protect,
    loadWorkspace,
    loadWorkspaceMembership,
    isMemberOrOwner,
    loadProject,
    updateTask
);

router.patch(
    "/:workspaceId/projects/:projectId/tasks/:taskId/archive",
    protect,
    loadWorkspace,
    loadWorkspaceMembership,
    isOwner,
    loadProject,
    archiveTask
);
export default router;